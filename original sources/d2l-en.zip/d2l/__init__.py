from .d2l import *

__version__ = '0.11.2'
